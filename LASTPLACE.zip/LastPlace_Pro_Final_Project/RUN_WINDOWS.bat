@echo off
cd /d "%~dp0"
echo === LastPlace Pro v5 Setup ===
call flutter create . --platforms android,web
if errorlevel 1 goto failed
call flutter pub get
if errorlevel 1 goto failed
echo.
echo Setup finished. Run: flutter run -d chrome
pause
exit /b 0
:failed
echo Setup failed. Copy the error and ask for help.
pause
exit /b 1

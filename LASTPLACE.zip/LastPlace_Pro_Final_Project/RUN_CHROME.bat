@echo off
cd /d "%~dp0"
call flutter run -d chrome
pause

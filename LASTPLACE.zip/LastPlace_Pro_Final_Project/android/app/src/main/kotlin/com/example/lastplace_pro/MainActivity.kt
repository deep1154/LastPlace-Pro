package com.example.lastplace_pro

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

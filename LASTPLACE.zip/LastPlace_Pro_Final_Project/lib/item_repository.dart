import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart' as p;

/// Android/iOS: SQLite persistence. Web: legacy SharedPreferences fallback.
/// Legacy data is imported once and kept untouched for safe rollback.
class ItemRepository {
  static const legacyItems = 'lastplace_items_v1';
  static const legacyHistory = 'lastplace_history_v3';
  static const legacyTrash = 'lastplace_trash_v3';
  static const migrationFlag = 'lastplace_sqlite_migrated_v5';
  Database? _db;
  Future<void> init() async {
    if (kIsWeb) return;
    final base = await getDatabasesPath();
    _db = await openDatabase(p.join(base, 'lastplace_v5.db'), version: 1,
      onCreate: (db, version) async {
        await db.execute('CREATE TABLE items (id TEXT PRIMARY KEY, payload TEXT NOT NULL, is_trashed INTEGER NOT NULL DEFAULT 0)');
        await db.execute('CREATE TABLE activity (id INTEGER PRIMARY KEY AUTOINCREMENT, payload TEXT NOT NULL)');
      });
    final prefs = await SharedPreferences.getInstance();
    if (prefs.getBool(migrationFlag) == true) return;
    final count = Sqflite.firstIntValue(await _db!.rawQuery('SELECT COUNT(*) FROM items')) ?? 0;
    if (count == 0) {
      final legacy = _decodeList(prefs.getString(legacyItems));
      final trash = _decodeList(prefs.getString(legacyTrash));
      final activity = _decodeList(prefs.getString(legacyHistory));
      await _db!.transaction((txn) async {
        for (final item in legacy) {
          await txn.insert('items', {'id': '${item['id']}', 'payload': jsonEncode(item), 'is_trashed': 0}, conflictAlgorithm: ConflictAlgorithm.replace);
        }
        for (final item in trash) {
          await txn.insert('items', {'id': '${item['id']}', 'payload': jsonEncode(item), 'is_trashed': 1}, conflictAlgorithm: ConflictAlgorithm.replace);
        }
        for (final event in activity.reversed) {
          await txn.insert('activity', {'payload': jsonEncode(event)});
        }
      });
    }
    await prefs.setBool(migrationFlag, true);
  }
  List<Map<String,dynamic>> _decodeList(String? raw) {
    try { return (jsonDecode(raw ?? '[]') as List).map((e) => Map<String,dynamic>.from(e as Map)).toList(); }
    catch (_) { return []; }
  }
  Future<Map<String,List<Map<String,dynamic>>>> readAll() async {
    if (kIsWeb) {
      final prefs = await SharedPreferences.getInstance();
      return {'items': _decodeList(prefs.getString(legacyItems)), 'trash': _decodeList(prefs.getString(legacyTrash)), 'history': _decodeList(prefs.getString(legacyHistory))};
    }
    final rows = await _db!.query('items');
    final events = await _db!.query('activity', orderBy: 'id DESC', limit: 300);
    return {
      'items': rows.where((r) => r['is_trashed'] == 0).map((r) => Map<String,dynamic>.from(jsonDecode(r['payload'] as String) as Map)).toList(),
      'trash': rows.where((r) => r['is_trashed'] == 1).map((r) => Map<String,dynamic>.from(jsonDecode(r['payload'] as String) as Map)).toList(),
      'history': events.map((r) => Map<String,dynamic>.from(jsonDecode(r['payload'] as String) as Map)).toList(),
    };
  }
  Future<void> writeAll({required List<Map<String,dynamic>> items, required List<Map<String,dynamic>> trash, required List<Map<String,dynamic>> history}) async {
    if (kIsWeb) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(legacyItems, jsonEncode(items));
      await prefs.setString(legacyTrash, jsonEncode(trash));
      await prefs.setString(legacyHistory, jsonEncode(history));
      return;
    }
    await _db!.transaction((txn) async {
      await txn.delete('items');
      for (final item in items) {
        await txn.insert('items', {'id': '${item['id']}', 'payload': jsonEncode(item), 'is_trashed': 0});
      }
      for (final item in trash) {
        await txn.insert('items', {'id': '${item['id']}', 'payload': jsonEncode(item), 'is_trashed': 1});
      }
      await txn.delete('activity');
      for (final event in history.reversed) {
        await txn.insert('activity', {'payload': jsonEncode(event)});
      }
    });
  }
  Future<void> dispose() async { await _db?.close(); }
}

import 'dart:convert';
import 'dart:typed_data';
import 'package:flutter/services.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'item_repository.dart';
import 'qr_scanner_page.dart';

void main() => runApp(const LastPlaceApp());
const purple = Color(0xFF6750C8);
const categories = ['Study', 'Electronics', 'Documents', 'Personal', 'Other'];

class StoredItem {
  String id, name, place, note, category;
  String? photo;
  bool favorite;
  DateTime createdAt;
  DateTime? reminder;
  StoredItem({required this.id, required this.name, required this.place,
    this.note = '', this.category = 'Other', this.photo, this.favorite = false,
    DateTime? createdAt, this.reminder}) : createdAt = createdAt ?? DateTime.now();
  factory StoredItem.fromJson(Map<String, dynamic> j) => StoredItem(
    id: '${j['id'] ?? ''}', name: '${j['name'] ?? ''}', place: '${j['place'] ?? ''}',
    note: '${j['note'] ?? ''}', category: '${j['category'] ?? 'Other'}',
    photo: j['photo'] as String?, favorite: j['favorite'] == true,
    createdAt: DateTime.tryParse('${j['createdAt'] ?? ''}'),
    reminder: DateTime.tryParse('${j['reminder'] ?? ''}'));
  Map<String, dynamic> toJson() => {'id': id, 'name': name, 'place': place,
    'note': note, 'category': category, 'photo': photo, 'favorite': favorite,
    'createdAt': createdAt.toIso8601String(), 'reminder': reminder?.toIso8601String()};
}

class LastPlaceApp extends StatelessWidget {
  const LastPlaceApp({super.key});
  @override Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false, title: 'LastPlace Pro',
    theme: ThemeData(useMaterial3: true, colorScheme: ColorScheme.fromSeed(seedColor: purple),
      scaffoldBackgroundColor: const Color(0xFFF8F7FD),
      inputDecorationTheme: InputDecorationTheme(border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)))),
    home: const HomePage());
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}
class _HomePageState extends State<HomePage> {
  final ItemRepository repository = ItemRepository();
  List<StoredItem> items = [];
  bool loading = true, favoritesOnly = false;
  String search = '', category = 'All';
  int tab = 0;
  List<Map<String, dynamic>> history = [];
  List<StoredItem> trash = [];
  static const historyKey = 'lastplace_history_v3';
  static const trashKey = 'lastplace_trash_v3';
  @override void initState() { super.initState(); load(); }
  @override void dispose() { repository.dispose(); super.dispose(); }
  Future<void> load() async {
    try {
      await repository.init();
      final data = await repository.readAll();
      items = data['items']!.map((e) => StoredItem.fromJson(e)).toList();
      trash = data['trash']!.map((e) => StoredItem.fromJson(e)).toList();
      history = data['history']!;
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Storage error: $e')));
    }
    if (mounted) setState(() => loading = false);
  }
  Future<void> save() async {
    await repository.writeAll(items: items.map((e) => e.toJson()).toList(),
      trash: trash.map((e) => e.toJson()).toList(), history: history);
  }
  Future<void> edit([StoredItem? item]) async {
    final result = await Navigator.push<StoredItem>(context,
      MaterialPageRoute(builder: (_) => ItemForm(item: item)));
    if (result == null) return;
    setState(() {
      final previous = items.where((x) => x.id == result.id).firstOrNull;
      logEvent(previous == null ? 'Added' : (previous.place != result.place ? 'Moved' : 'Updated'), result);
      final index = items.indexWhere((x) => x.id == result.id);
      if (index < 0) { items.insert(0, result); } else { items[index] = result; }
    });
    await save();
  }
  Future<void> remove(StoredItem item) async {
    final ok = await showDialog<bool>(context: context, builder: (c) => AlertDialog(
      title: const Text('Delete item?'), content: Text('Remove ${item.name} from LastPlace?'),
      actions: [TextButton(onPressed: () => Navigator.pop(c, false), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(c, true), child: const Text('Delete'))]));
    if (ok != true) return;
    setState(() { items.removeWhere((x) => x.id == item.id); trash.insert(0, item); logEvent('Trashed', item); });
    await save();
  }
  Future<void> toggleFavorite(StoredItem item) async {
    setState(() { item.favorite = !item.favorite; logEvent(item.favorite ? 'Favorited' : 'Unfavorited', item); });
    await save();
  }
  void logEvent(String action, StoredItem item) {
    history.insert(0, {'action': action, 'name': item.name, 'place': item.place,
      'time': DateTime.now().toIso8601String()});
    if (history.length > 300) history = history.take(300).toList();
  }
  Future<void> restore(StoredItem item) async {
    setState(() { trash.removeWhere((e) => e.id == item.id); items.insert(0,item); logEvent('Restored',item); });
    await save();
  }
  Future<void> exportBackup() async {
    final payload = jsonEncode({'schema': 3, 'items': items.map((e)=>e.toJson()).toList(),
      'trash': trash.map((e)=>e.toJson()).toList(), 'history': history});
    await Clipboard.setData(ClipboardData(text: payload));
    if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Backup JSON copied to clipboard. Save it somewhere safe.')));
  }
  Future<void> importBackup() async {
    final controller = TextEditingController();
    final confirmed = await showDialog<bool>(context: context, builder: (c) => AlertDialog(
      title: const Text('Import backup'),
      content: SizedBox(width: 500, child: TextField(controller: controller, maxLines: 8,
        decoration: const InputDecoration(hintText: 'Paste LastPlace backup JSON'))),
      actions: [TextButton(onPressed: ()=>Navigator.pop(c,false),child: const Text('Cancel')),
        FilledButton(onPressed: ()=>Navigator.pop(c,true),child: const Text('Import'))]));
    if (confirmed != true) { controller.dispose(); return; }
    try {
      final decoded = jsonDecode(controller.text) as Map<String,dynamic>;
      if (decoded['schema'] != 3 || decoded['items'] is! List) throw const FormatException('Invalid backup format');
      final newItems = (decoded['items'] as List).map((e)=>StoredItem.fromJson(Map<String,dynamic>.from(e as Map))).toList();
      final newTrash = ((decoded['trash'] as List?) ?? []).map((e)=>StoredItem.fromJson(Map<String,dynamic>.from(e as Map))).toList();
      final newHistory = ((decoded['history'] as List?) ?? []).map((e)=>Map<String,dynamic>.from(e as Map)).toList();
      if (mounted) setState(() { items = newItems; trash = newTrash; history = newHistory; });
      await save();
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Backup imported successfully')));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Import failed: $e')));
    } finally { controller.dispose(); }
  }
  Widget analyticsView() {
    final counts = {for (final c in categories) c: items.where((e)=>e.category==c).length};
    final maxCount = counts.values.fold<int>(1,(a,b)=>b>a?b:a);
    final locations = <String,int>{};
    for (final item in items) { final loc=item.place.trim(); locations[loc]=(locations[loc]??0)+1; }
    final top = locations.entries.toList()..sort((a,b)=>b.value.compareTo(a.value));
    return ListView(padding: const EdgeInsets.all(18),children: [
      const Text('Collection insights',style: TextStyle(fontSize:24,fontWeight:FontWeight.bold)),
      const SizedBox(height:8), Text('${items.length} active items • ${trash.length} in recycle bin • ${history.length} recent events'),
      const SizedBox(height:20), const Text('Items by category',style: TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
      ...counts.entries.map((e)=>Padding(padding: const EdgeInsets.symmetric(vertical:9),child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,children:[Text('${e.key}: ${e.value}'),
        const SizedBox(height:5),LinearProgressIndicator(value:e.value/maxCount,minHeight:10,borderRadius:BorderRadius.circular(8))]))),
      const SizedBox(height:18),const Text('Most used locations',style: TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
      ...top.take(8).map((e)=>ListTile(leading:const Icon(Icons.place_outlined),title:Text(e.key),trailing:Text('${e.value} items'))),
      if (top.isEmpty) const Text('Add items to see location statistics.'),
    ]);
  }
  Widget activityView() => ListView(padding: const EdgeInsets.all(18),children: [
    const Text('Activity timeline',style: TextStyle(fontSize:24,fontWeight:FontWeight.bold)),
    const SizedBox(height:8),const Text('Recent actions are stored on this device.'),
    if (history.isEmpty) const Padding(padding: EdgeInsets.all(30),child:Text('No activity yet.')),
    ...history.map((e)=>Card(child:ListTile(leading:const Icon(Icons.history),
      title:Text('${e['action']} • ${e['name']}'),subtitle:Text('${e['place']}'),
      trailing:Text('${(e['time'] as String).substring(0,10)}',style:const TextStyle(fontSize:11))))),
  ]);
  Widget settingsView() => ListView(padding: const EdgeInsets.all(18),children: [
    const Text('Data & recovery',style: TextStyle(fontSize:24,fontWeight:FontWeight.bold)),
    const SizedBox(height:8),const Text('Android/iOS: SQLite database. Web: SharedPreferences fallback. Export a backup before changing installations.'),
    Card(child:Column(children:[
      ListTile(leading:const Icon(Icons.copy_all),title:const Text('Copy JSON backup'),
        subtitle:const Text('Includes items, photos, trash and history'),onTap:exportBackup),
      const Divider(height:1),
      ListTile(leading:const Icon(Icons.settings_backup_restore),title:const Text('Restore from JSON'),
        subtitle:const Text('Replaces current data; make a backup first'),onTap:importBackup),
    ])),
    const SizedBox(height:20),Text('Recycle bin (${trash.length})',style:const TextStyle(fontSize:18,fontWeight:FontWeight.bold)),
    if (trash.isEmpty) const Padding(padding:EdgeInsets.all(15),child:Text('Recycle bin is empty.')),
    ...trash.map((e)=>Card(child:ListTile(title:Text(e.name),subtitle:Text(e.place),
      trailing:TextButton(onPressed:()=>restore(e),child:const Text('Restore'))))),
    const SizedBox(height:20),const Text('Reminder dates are in-app only. This prototype does not send background push notifications.'),
  ]);
  void showQr(StoredItem item) {
    showDialog<void>(context: context, builder: (ctx) => AlertDialog(
      title: Text('QR label: ${item.name}'),
      content: Column(mainAxisSize: MainAxisSize.min, children: [
        QrImageView(data: 'LASTPLACE:${item.id}', version: QrVersions.auto, size: 220),
        const SizedBox(height: 12),
        SelectableText('LASTPLACE:${item.id}', textAlign: TextAlign.center),
        const SizedBox(height: 8),
        Text('Place: ${item.place}', textAlign: TextAlign.center),
        const Text('Keep this label with your item. Use Find by ID to retrieve it.', textAlign: TextAlign.center),
      ]),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Close'))],
    ));
  }
  Future<void> findById() async {
    final controller = TextEditingController();
    final query = await showDialog<String>(context: context, builder: (ctx) => AlertDialog(
      title: const Text('Find item by QR ID'),
      content: TextField(controller: controller, autofocus: true,
        decoration: const InputDecoration(labelText: 'Paste LASTPLACE: ID or item ID')),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
        FilledButton(onPressed: () => Navigator.pop(ctx, controller.text.trim()), child: const Text('Find'))],
    ));
    controller.dispose();
    if (query != null) showItemForQr(query);
  }
  Future<void> scanQr() async {
    final value = await Navigator.push<String>(context,
      MaterialPageRoute(builder: (_) => const QrScannerPage()));
    if (value != null) showItemForQr(value);
  }
  void showItemForQr(String query) {
    if (!mounted || query.isEmpty) return;
    final id = query.startsWith('LASTPLACE:') ? query.substring('LASTPLACE:'.length) : query;
    StoredItem? found;
    for (final item in items) { if (item.id == id) { found = item; break; } }
    if (found == null) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('No active item found for that QR code')));
      return;
    }
    final item = found;
    showDialog<void>(context: context, builder: (ctx) => AlertDialog(
      title: Text(item.name), content: Text('Location: ${item.place}\nCategory: ${item.category}\nNote: ${item.note}'),
      actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Close'))]));
  }
  IconData iconFor(String cat) => switch(cat) {
    'Study' => Icons.menu_book_rounded, 'Electronics' => Icons.headphones_rounded,
    'Documents' => Icons.description_rounded, 'Personal' => Icons.key_rounded,
    _ => Icons.inventory_2_rounded};
  Widget stat(String label, String value, IconData icon) => Expanded(child: Card(
    color: Colors.white, elevation: 0, child: Padding(padding: const EdgeInsets.all(12),
    child: Column(children: [Icon(icon, color: purple), const SizedBox(height: 6),
      Text(value, style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
      Text(label, style: const TextStyle(fontSize: 11))]))));
  @override Widget build(BuildContext context) {
    final now = DateTime.now();
    final due = items.where((e) => e.reminder != null && !e.reminder!.isAfter(now)).length;
    final filtered = items.where((e) {
      final q = search.toLowerCase();
      return (category == 'All' || e.category == category) && (!favoritesOnly || e.favorite) &&
        ('${e.name} ${e.place} ${e.category} ${e.note}'.toLowerCase().contains(q));
    }).toList()..sort((a,b) => b.createdAt.compareTo(a.createdAt));
    return Scaffold(appBar: AppBar(title: const Text('LastPlace Pro', style: TextStyle(fontWeight: FontWeight.bold)),
      actions: [IconButton(tooltip: 'Scan QR with camera', onPressed: scanQr, icon: const Icon(Icons.camera_alt_outlined)), IconButton(tooltip: 'Find by QR ID', onPressed: findById, icon: const Icon(Icons.qr_code_scanner)), IconButton(tooltip: 'About', onPressed: () => showAboutDialog(context: context,
        applicationName: 'LastPlace Pro', applicationVersion: '5.0', children: [
          const Text('Offline item organizer. Reminders are shown inside the app, not as phone notifications.')]),
        icon: const Icon(Icons.info_outline))]),
      bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected:(v)=>setState(()=>tab=v), destinations:const [
        NavigationDestination(icon:Icon(Icons.inventory_2_outlined),label:'Items'),
        NavigationDestination(icon:Icon(Icons.bar_chart_outlined),label:'Insights'),
        NavigationDestination(icon:Icon(Icons.history),label:'Activity'),
        NavigationDestination(icon:Icon(Icons.settings_outlined),label:'Data')]),
      floatingActionButton: tab == 0 ? FloatingActionButton.extended(onPressed: () => edit(),
        icon: const Icon(Icons.add), label: const Text('Add item')) : null,
      body: loading ? const Center(child: CircularProgressIndicator()) : tab == 1 ? analyticsView() : tab == 2 ? activityView() : tab == 3 ? settingsView() : SafeArea(child:
        Column(children: [Expanded(child: ListView(padding: const EdgeInsets.fromLTRB(16, 12, 16, 90), children: [
          Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(color: purple,
            borderRadius: BorderRadius.circular(22)), child: const Column(
            crossAxisAlignment: CrossAxisAlignment.start, children: [
              Icon(Icons.place, color: Colors.white, size: 32), SizedBox(height: 10),
              Text('Never forget a place again', style: TextStyle(color: Colors.white,
                fontSize: 21, fontWeight: FontWeight.bold)), SizedBox(height: 5),
              Text('Save • Organize • Remember', style: TextStyle(color: Colors.white70))])),
          const SizedBox(height: 12),
          Row(children: [stat('Items', '${items.length}', Icons.inventory_2_outlined),
            stat('Favorites', '${items.where((e) => e.favorite).length}', Icons.star_outline),
            stat('Due', '$due', Icons.notifications_active_outlined)]),
          if (due > 0) Card(color: const Color(0xFFFFF2D8), child: ListTile(
            leading: const Icon(Icons.notifications_active_outlined),
            title: Text('$due reminder(s) due'), subtitle: const Text('Open an item to update its reminder.'))),
          const SizedBox(height: 10),
          TextField(onChanged: (v) => setState(() => search = v),
            decoration: const InputDecoration(prefixIcon: Icon(Icons.search),
              labelText: 'Search name, place or note', filled: true, fillColor: Colors.white)),
          const SizedBox(height: 10),
          Row(children: [Expanded(child: DropdownButtonFormField<String>(
            initialValue: category, decoration: const InputDecoration(labelText: 'Category', isDense: true),
            items: ['All', ...categories].map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
            onChanged: (v) => setState(() => category = v ?? 'All'))),
            const SizedBox(width: 8), FilterChip(label: const Text('Favorites'), selected: favoritesOnly,
              onSelected: (v) => setState(() => favoritesOnly = v))]),
          const SizedBox(height: 18),
          Text('Saved items (${filtered.length})', style: const TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          if (filtered.isEmpty) const Padding(padding: EdgeInsets.all(40), child: Center(
            child: Text('No items found. Tap Add item to start.'))),
          ...filtered.map((item) => Card(color: Colors.white, elevation: 0,
            margin: const EdgeInsets.only(bottom: 10), child: Padding(padding: const EdgeInsets.all(8),
            child: Row(children: [
              if (item.photo != null) ClipRRect(borderRadius: BorderRadius.circular(12),
                child: Image.memory(base64Decode(item.photo!), width: 65, height: 65, fit: BoxFit.cover))
              else CircleAvatar(radius: 30, backgroundColor: const Color(0xFFEDE7FF),
                child: Icon(iconFor(item.category), color: purple)),
              const SizedBox(width: 10), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                children: [Text(item.name, style: const TextStyle(fontWeight: FontWeight.bold)),
                  Text('📍 ${item.place}', maxLines: 2, overflow: TextOverflow.ellipsis),
                  Text(item.category, style: const TextStyle(fontSize: 12, color: Colors.grey)),
                  if (item.reminder != null) Text('Reminder: ${formatDate(item.reminder!)}',
                    style: TextStyle(fontSize: 11, color: item.reminder!.isAfter(now) ? purple : Colors.deepOrange))])),
              Column(children: [IconButton(tooltip: 'Favorite', onPressed: () => toggleFavorite(item),
                icon: Icon(item.favorite ? Icons.star : Icons.star_border, color: purple)),
                PopupMenuButton<String>(tooltip: 'Item actions', onSelected: (v) { if (v == 'edit') { edit(item); } else if (v == 'qr') { showQr(item); } else { remove(item); } },
                  itemBuilder: (_) => [const PopupMenuItem(value: 'qr', child: Text('Show QR label')), const PopupMenuItem(value: 'edit', child: Text('Edit')),
                    const PopupMenuItem(value: 'delete', child: Text('Delete'))])])])))),
        ]))])));
  }
}

String formatDate(DateTime d) => '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';

class ItemForm extends StatefulWidget {
  final StoredItem? item;
  const ItemForm({super.key, this.item});
  @override State<ItemForm> createState() => _ItemFormState();
}
class _ItemFormState extends State<ItemForm> {
  final formKey = GlobalKey<FormState>();
  late final TextEditingController name, place, note;
  late String category;
  String? photo;
  DateTime? reminder;
  bool busy = false;
  @override void initState() {
    super.initState(); final item = widget.item;
    name = TextEditingController(text: item?.name ?? '');
    place = TextEditingController(text: item?.place ?? '');
    note = TextEditingController(text: item?.note ?? '');
    category = categories.contains(item?.category) ? item!.category : 'Other';
    photo = item?.photo; reminder = item?.reminder;
  }
  @override void dispose() { name.dispose(); place.dispose(); note.dispose(); super.dispose(); }
  Future<void> pickPhoto() async {
    try {
      final x = await ImagePicker().pickImage(source: ImageSource.gallery,
        maxWidth: 700, maxHeight: 700, imageQuality: 55);
      if (x == null) return;
      final bytes = await x.readAsBytes();
      if (bytes.length > 600000) {
        if (mounted) ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Photo too large. Choose a smaller image.')));
        return;
      }
      setState(() => photo = base64Encode(bytes));
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Photo unavailable: $e')));
    }
  }
  Future<void> chooseDate() async {
    final d = await showDatePicker(context: context, initialDate: reminder ?? DateTime.now(),
      firstDate: DateTime(2020), lastDate: DateTime(2100));
    if (d != null) setState(() => reminder = d);
  }
  void submit() {
    if (!(formKey.currentState?.validate() ?? false)) return;
    final old = widget.item;
    Navigator.pop(context, StoredItem(id: old?.id ?? DateTime.now().microsecondsSinceEpoch.toString(),
      name: name.text.trim(), place: place.text.trim(), note: note.text.trim(),
      category: category, photo: photo, favorite: old?.favorite ?? false,
      createdAt: old?.createdAt, reminder: reminder));
  }
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.item == null ? 'Add item' : 'Edit item')),
    body: Form(key: formKey, child: ListView(padding: const EdgeInsets.all(20), children: [
      const Text('Remember the exact place', style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
      const SizedBox(height: 18),
      TextFormField(controller: name, maxLength: 50, decoration: const InputDecoration(labelText: 'Item name *'),
        validator: (v) => v == null || v.trim().isEmpty ? 'Enter item name' : null),
      TextFormField(controller: place, maxLength: 100, decoration: const InputDecoration(labelText: 'Location *'),
        validator: (v) => v == null || v.trim().isEmpty ? 'Enter location' : null),
      DropdownButtonFormField<String>(initialValue: category, decoration: const InputDecoration(labelText: 'Category'),
        items: categories.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
        onChanged: (v) => setState(() => category = v ?? 'Other')),
      const SizedBox(height: 16),
      TextFormField(controller: note, maxLines: 2, maxLength: 150,
        decoration: const InputDecoration(labelText: 'Note (optional)')),
      const SizedBox(height: 12),
      if (photo != null) Image.memory(base64Decode(photo!), height: 150, fit: BoxFit.contain),
      Row(children: [OutlinedButton.icon(onPressed: busy ? null : pickPhoto,
        icon: const Icon(Icons.photo_library_outlined), label: const Text('Choose photo')),
        if (photo != null) TextButton(onPressed: () => setState(() => photo = null), child: const Text('Remove photo'))]),
      const SizedBox(height: 12),
      ListTile(contentPadding: EdgeInsets.zero, leading: const Icon(Icons.event),
        title: Text(reminder == null ? 'Add in-app reminder' : 'Reminder: ${formatDate(reminder!)}'),
        subtitle: const Text('Shows as due on the dashboard; no push notification'),
        onTap: chooseDate, trailing: reminder == null ? null : IconButton(
          onPressed: () => setState(() => reminder = null), icon: const Icon(Icons.clear))),
      const SizedBox(height: 24),
      FilledButton.icon(onPressed: submit, icon: const Icon(Icons.save),
        label: Text(widget.item == null ? 'Save item' : 'Update item')),
    ])));
}

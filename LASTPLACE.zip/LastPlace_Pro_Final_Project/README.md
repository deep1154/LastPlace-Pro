# LastPlace Pro v5 — SQLite + Camera QR Scanning

This is a separate upgrade of v4. **Keep your original project and ZIP untouched.**

## Implemented
- Existing v4 item CRUD, photos, categories, favorites, search, analytics, history, trash, JSON clipboard backup, QR label generation and manual ID lookup.
- **New:** SQLite storage on Android/iOS (tables `items`, `activity`). First launch imports v4 SharedPreferences records once, leaving old keys unchanged.
- **New:** Camera QR scanning with `mobile_scanner`, resolving labels of the form `LASTPLACE:<item-id>`.
- **Web fallback:** SharedPreferences (SQLite not used on Chrome). Browser camera scanning may depend on HTTPS/browser camera permissions; **Android phone recommended**.

## Windows setup
1. Extract this ZIP into a **new** directory, e.g. `C:\\Users\\DeepSutariya\\LastPlace_V5_SQLite_QR`.
2. Open CMD in that directory (it contains `pubspec.yaml`).
3. `flutter create . --platforms android,web`
4. `flutter pub get`
5. Connect Android phone via USB, enable Developer Options > USB debugging, approve authorization.
6. `flutter devices`
7. `flutter run -d <device-id>` (or `flutter run` if only one device).
8. Chrome UI demo: `flutter run -d chrome` (uses SharedPreferences, **not SQLite**).

## Android camera permission
`mobile_scanner` may merge its required Android permissions through the plugin. For a reliable explicit declaration, open `android/app/src/main/AndroidManifest.xml` and add the following **directly inside `<manifest>`**, before `<application>`:
`<uses-permission android:name="android.permission.CAMERA" />`
Do not put it inside `<application>`. Android requests camera permission at runtime.

## QR demo
Add an item > menu > Show QR label. Display QR on another device/printout, then tap camera icon in the top app bar and scan. The item name/location will appear.

## Migration note
Data saved in Chrome is stored in that browser origin and does **not** automatically transfer to Android. Use JSON backup/restore to move records between installations. Existing v4 Android SharedPreferences data is migrated on first launch of v5 if installed with the **same application ID**. Changing application ID or installing on another device does not migrate data automatically.

## Limitations
No Firebase, background push reminders, cloud sync or PDF reports. Current save operation rewrites the SQLite item/activity tables transactionally, suitable for a college prototype but not optimized for huge inventories. This project was not Flutter-compiled in this environment; test on your computer and share any error output.
